# importing modules
import turtle
import random
turtle.delay(0)
turtle.Screen().title("Python Maze generator")
# defining turtle object
t = turtle.Turtle()
t.shapesize(0.5, 1, 1)
t.hideturtle()
t.shape("turtle")
#setting up list(s)
written_cors=[]
last_desision_point = []
last_desision = []
last_heading = []
# setting up variable(s)
render_speed = 0
pensize = 0
def forward(pixels, write_list = True, speed = 0): 
    xcor = t.xcor()
    ycor = t.ycor()
    for i in range(pixels):
        if write_list:
            if t.heading() == 270:
                ycor -= 1
            elif t.heading() == 90:
                ycor += 1
            elif t.heading() == 0:
                xcor += 1
            elif t.heading() == 180:
                xcor -= 1
            written_cors.append([round(xcor),round(ycor)])
    t.forward(pixels)
def write_new_desision(desision):
    last_heading.append(t.heading())
    if desision == -1: 
        last_desision.append([1,0,0])
    elif desision == 0: 
        last_desision.append([0,1,0])
    elif desision == 1: 
        last_desision.append([0,0,1])
    last_desision_point.append([t.xcor(), t.ycor()])
# setting turtle colours
turtle.bgcolor("black")
t.pencolor("white")
# getting maze size
while True: 
    try: 
        maze_size = int(input("Enter maze size: "))
        break
    except: 
        print("Invaild maze size. ")
while True: 
    try: 
        print("Avaliable path width can only be integers (Difficulty levels: 1>Hard, 2>Normal, 3>Easy 4,5,6... --> Super Easy )")
        pensize = int(input("Enter path width: "))
        if not pensize == 0:
            break
        else: 
            print("Invalid path width")
    except: 
        print("Invalid path width")
# setting turtle penszie
t.pensize(5*pensize)
# setting maze size variables
maze_length = maze_size
highest_x = 0 + (maze_length/2)
lowest_x = 0 - (maze_length/2)
highest_y = highest_x
lowest_y = lowest_x
# setting up ending variables
longest_path_dis = 0
longest_path_endpos = [lowest_x, 0]
current_path_distence = 0
# drawing maze box
print("Rendering maze box...")
t.pencolor("gray")
t.penup()
t.goto(lowest_x, lowest_y)
t.setheading(90)
t.pendown()
for i in range(4): 
    forward(maze_length, True, 0)
    t.right(90)
t.penup()
t.pencolor("white")
# setting turtle functions
print("Setting up functions... ")
t.penup()
t.goto(lowest_x, 0)
t.speed(render_speed)
t.setheading(0)
t.pendown()
t.fillcolor("spring green")
t.shape("arrow")
t.stamp()
t.fillcolor("black")
t.shape("turtle")
forward(20*pensize)
t.penup()
# defining scout object
scout = turtle.Turtle()
scout.speed(render_speed)
scout.hideturtle()
scout.penup()
scout.shapesize(0.5*pensize,0.5*pensize,0.5*pensize)
# rendering maze
print("Preparing some variables... ")
make_new_point = True
rendering = True
print("Starting to render maze... ")
print("Rendering maze... ")
while rendering: 
    scout.goto(t.position())
    scout.setheading(t.heading())
    if make_new_point: 
        desision = random.choice([-1,0,1])
    scout.right(90*desision)
    scout.forward(10*pensize)
    if [round(scout.xcor()),round(scout.ycor())] in written_cors or scout.xcor() > highest_x or scout.xcor() < lowest_x or scout.ycor() > highest_y or scout.ycor() < lowest_y: 
        try: 
            if last_desision[1] == [1,1,1]: 
                last_desision.pop(1)
                last_desision_point.pop(1)
                last_heading.pop(1)
                #current_path_distence = 0
            else: 
                t.goto(last_desision_point[1])
                t.setheading(last_heading[1])
                make_new_point = False
                if random.choice([1,2]) == 1: 
                    if not last_desision[1][0] == 1: 
                        desision = -1
                        last_desision[1] = [1, last_desision[1][1], last_desision[1][2]]
                    elif not last_desision[1][1] == 1: 
                        desision = 0
                        last_desision[1] = [last_desision[1][0], 1, last_desision[1][2]]
                    elif not last_desision[1][2] == 1: 
                        desision = 1
                        last_desision[1] = [last_desision[1][0], last_desision[1][1], 1]
                else: 
                    if not last_desision[1][1] == 1: 
                        desision = 0
                        last_desision[1] = [last_desision[1][0], 1, last_desision[1][2]]
                    elif not last_desision[1][2] == 1: 
                        desision = 1
                        last_desision[1] = [last_desision[1][0], last_desision[1][1], 1]
                    elif not last_desision[1][0] == 1: 
                        desision = -1
                        last_desision[1] = [1, last_desision[1][1], last_desision[1][2]]
        except: 
            rendering = False
            break

    else: 
        t.pendown()
        t.right(90*desision)
        write_new_desision(desision)
        forward(10*pensize)
        t.penup()
        current_path_distence +=1 
        if current_path_distence >= longest_path_dis: 
            longest_path_dis = current_path_distence
            longest_path_endpos = [t.xcor(), t.ycor()]
        make_new_point = True
    if not last_desision: 
        rendering = False
        break

# rendering complete
print("Maze rendering complete! ")
# creating end point
print("Rendering end point...")
t.goto(longest_path_endpos)
t.fillcolor("red")
t.shape("circle")
t.showturtle()
t.shapesize(0.5,0.5,0)
t.stamp()
print("End point created")
# making finishing touches
print("Making finishing touches... ")
# solving maze time
input("Press ENTER to exit...")
turtle.Screen().bye()
# saving turtle canvas
print("Saving image...")

import pygame
surface = pygame.Surface((maze_length, maze_length))
penr = pensize*2.5
adjustcors = maze_length/2
# rendering written maze
for i in range(0, len(written_cors)-1): 
    pygame.draw.circle(surface, (255, 255, 255), (written_cors[i][0]+adjustcors, abs(written_cors[i][1]-adjustcors)), penr)

# making start/end point
pygame.draw.polygon(surface, (0, 255, 0), ([10, adjustcors-5], [10, adjustcors+5], [17, adjustcors])) # rendering start point
pygame.draw.circle(surface, (255, 0, 0), (longest_path_endpos[0]+adjustcors, abs(longest_path_endpos[1]-adjustcors)), penr) # rendering end point 
pygame.image.save(surface, input("Enter file name: ")+".png")

print("Image saved. ") 