from os import startfile 
import os
from PIL import Image 
import tkinter 
import tkinter.filedialog 
import pygame 
import pickle 

pygame.init() 
projectname = "Item Locator" 
screen = pygame.display.set_mode((700, 530)) 
pygame.display.set_caption(projectname) 

backcolour = False 
activecol = pygame.Color('lightskyblue3') 
inactivecol = pygame.Color('dodgerblue2') 

if not "infos" in os.listdir(): 
    os.mkdir("infos")

def rectwithtext(x, y, width, height, text, font, colour, background=False, fontsize: int = "Default", blitscreen = screen): 
    if fontsize == "Default": 
        fontsize = int(32/30*height) 
    textbox = pygame.Rect(x, y, width, height) 
    if background: 
        pygame.display.update(pygame.draw.rect(screen, (0, 0, 0), textbox)) 
    font = pygame.font.SysFont(font, fontsize) 
    text_surface = font.render(text, True, colour) 
    if text_surface.get_width() > width-4: 
        text_surface = pygame.transform.smoothscale(text_surface, (width-10, 25)) 
    textbox = pygame.draw.rect(screen, colour, textbox, 2) 
    blitscreen.blit(text_surface, (textbox.x+5, textbox.y+2.5)) 
    pygame.display.update(textbox) 
    return textbox 

noimgfoundsurf = pygame.Surface((100, 70)) 
rectwithtext(0, 17, 100, 17, "NO IMAGE", None, inactivecol, blitscreen=noimgfoundsurf) 
rectwithtext(0, 34, 100, 17, "FOUND", None, inactivecol, blitscreen=noimgfoundsurf) 
pygame.image.save(noimgfoundsurf, "NO IMAGE FOUND.png")
NoImageFound = r"NO IMAGE FOUND.png" 

def inputbox(x, y, width, height, font, hint=""): 
    hinting = False if hint == "" else True 
    font = pygame.font.SysFont(font, int(32/30*height))
    colour = inactivecol 
    keyed = hint 
    inputbox = pygame.Rect(x, y, width, height) 
    keying = True 
    while keying: 
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                keying = False 
                global run 
                run = False 
            if event.type == pygame.KEYDOWN: 
                if hinting: 
                    hinting = False 
                    keyed = ""
                if event.key == pygame.K_RETURN: 
                    keying = False 
                    return keyed[:-1]
                elif event.key == pygame.K_BACKSPACE: 
                    keyed = keyed[:-2]
                    keyed += "|" 
                else: 
                    keyed = keyed[:-1]
                    keyed += event.unicode
                    keyed += "|" 
        screen.fill((0, 0, 0)) 
        text_surface = font.render(keyed, True, colour) 
        inputbox.width = max(width, text_surface.get_width()+10) 
        screen.blit(text_surface, (inputbox.x+5, inputbox.y+5)) 
        pygame.display.update(pygame.draw.rect(screen, colour, inputbox, 2)) 

def prompt_file():
    top = tkinter.Tk()
    top.withdraw() 
    file_name = tkinter.filedialog.askopenfilename(parent=top) 
    top.destroy() 
    return file_name 

def convertstr(string): 
    toreturn = ""
    for letter in string: 
        toreturn += str(ord(letter)) 
    return toreturn 

class Item(): 
    def __init__(self, name, location, add="yes"): 
        self.name = name 
        self.location = location 
        if add == "yes": 
            location.add(self) 
        self.image = NoImageFound 
        self.surface = pygame.image.tostring(pygame.transform.scale(pygame.image.load(self.image), (100, 70)), "RGB") 
        self.info = "infos\\{} Info.txt".format(convertstr(self.name)) 
        with open (self.info, "w") as f: 
            f.write(f"{self.name}\'s information: Empty ") 
    def delete(self): 
        try: 
            self.location.remove(self) 
            os.remove(self.info) 
        except FileNotFoundError: 
            pass 
    def addimage(self, image): 
        self.image = r"{}".format(image) 
        self.surface = pygame.image.tostring(pygame.transform.scale(pygame.image.load(self.image), (100, 70)), "RGB") 
    def blitself(self, x, y): 
        self.rect = screen.blit(pygame.image.fromstring(self.surface, [100, 70], "RGB"),(x, y)) 
        if type(self).__name__ == "Item": 
            colour = activecol 
        else: 
            colour = inactivecol
        rectwithtext(x, y+70, 100, 30, self.name, None, colour)

class Folder(Item): 
    def __init__(self, name, location, add="yes"): 
        try: 
            Item.__init__(self, name, location, add) 
        except: 
            self.name = name 
        self.image = NoImageFound 
        self.items = [] 
    def add(self, item): 
        self.items.append(item) 
    def remove(self, item): 
        self.items.remove(item) 

def find(tofind, folder):
    global location 
    global founditem 
    for item in folder.items: 
        if item.name == tofind: 
            location = item.location 
            founditem = item
            return True 
        else: 
            if type(item).__name__ == "Folder": 
                if find(tofind, item): 
                    return True 
    return False 

def printall(folder): 
    for item in folder.items: 
        print(f"{item.name} | {type(item).__name__}") 
        if type(item).__name__ == "Folder": 
            printall(item) 

def getstringoflocation(item): 
    if item.name != "Main Folder": 
        toreturn = f"{item.name}: Main Folder" 
        prvitem = item.location 
        while prvitem.name != "Main Folder": 
            toreturn += f" --> {prvitem.name}" 
            prvitem = prvitem.location 
        return toreturn + " --> " + item.name 
    else: 
        return "Main Folder" 


def displayinfo(): 
    screen.fill((0, 0, 0))
    if viewing.items: 
        itemx = 0 
        itemy = adjusty + 30 
        for item in viewing.items: 
            item.blitself(itemx, itemy) 
            itemx += 100 
            if itemx == 700: 
                itemx = 0
                itemy += 100 
    else: 
        rectwithtext(0, 30, 700, 50, "This location is empty. ", None, activecol) 
    global searchbutton 
    searchbutton = rectwithtext(600, 0, 100, 30, "Search", None, activecol, True) 
    global backbutton 
    backbutton = rectwithtext(500, 0, 100, 30, "Back", None, activecol, True) 
    rectwithtext(0, 0, 500, 30, getstringoflocation(viewing) , None, activecol, True) 
    pygame.display.update() 

def displayops(type, event, item): 
    global run 
    notclicked = True 
    if type =="space": 
        x, y = pygame.mouse.get_pos() 
        newitem = rectwithtext(x, y, 200, 30, "New Item", None, inactivecol, True) 
        newfolder = rectwithtext(x, y+30, 200, 30, "New Location", None, inactivecol, True) 
        viewallitems = rectwithtext(x, y+60, 200, 30, "View all items", None, inactivecol, True) 
        while notclicked: 
            for event in pygame.event.get(): 
                if event.type == pygame.QUIT: 
                    notclicked = False 
                    run = False 
                if event.type == pygame.MOUSEBUTTONDOWN: 
                    if event.button == 1: 
                        displayinfo() 
                        if newitem.collidepoint(event.pos): 
                            newname = inputbox(x, y, 200, 30, None, "Item name") 
                            viewing.items.append(Item(newname, viewing, "no")) 
                        if newfolder.collidepoint(event.pos): 
                            newname = inputbox(x, y, 200, 30, None, "Location name") 
                            viewing.items.append(Folder(newname, viewing, "no"))
                        if viewallitems.collidepoint(event.pos): 
                            errormsg("Ready to print. ", "Please click/scroll then check the terminal/shell to view all items. ") 
                            print("All items: ") 
                            printall(Main_Folder) 
                        displayinfo() 
                        notclicked = False 
    else: 
        x, y = event.pos 
        rename = rectwithtext(x, y, 200, 30, "Rename", None, activecol, True) 
        delete = rectwithtext(x, y+30, 200, 30, "Delete", None, activecol, True) 
        changeimg = rectwithtext(x, y+60, 200, 30, "Change Image", None, activecol, True) 
        viewimage = rectwithtext(x, y+90, 200, 30, "View Image", None, activecol, True) 
        if type == "Folder": 
            viewinfo = rectwithtext(x, y+120, 200, 30, "View Info", None, activecol, True) 
        # elif type == "Item": 
        #     pass 
        notclicked = True 
        while notclicked: 
            for event in pygame.event.get(): 
                if event.type == pygame.QUIT: 
                    notclicked = False 
                    run = False 
                if event.type == pygame.MOUSEBUTTONDOWN: 
                    if event.button == 1: 
                        if rename.collidepoint(event.pos): 
                            item.name = inputbox(x, y, 200, 30, None, "New Name") 
                        elif delete.collidepoint(event.pos): 
                            item.delete() 
                        elif changeimg.collidepoint(event.pos): 
                            try: 
                                imgpath = prompt_file() 
                                pygame.image.load(imgpath) 
                                item.addimage(imgpath) 
                            except pygame.error as Unsupported_image_format: 
                                # display error msg 
                                errormsg("Error: Wrong Image File Type", "Click/Scroll to exit error screen") 
                            except FileNotFoundError: 
                                pass 
                        elif viewimage.collidepoint(event.pos): 
                            viewimage = rectwithtext(x, y+90, 200, 30, "View Image", None, inactivecol, True) 
                            image = Image.open(item.image)
                            image.show()
                            viewimage = rectwithtext(x, y+90, 200, 30, "View Image", None, inactivecol, True) 
                        try: 
                            if viewinfo.collidepoint(event.pos): 
                                try: 
                                    startfile(item.info) 
                                except FileNotFoundError: 
                                    errormsg("Error: File Not Found. ", "Creating new file. Old contents would not be there. ") 
                                    item.info = "infos\\{} Info.txt".format(convertstr(item.name)) 
                                    with open (item.info, "w") as f: 
                                        f.write(f"{item.name}\'s information: Empty ") 
                        except UnboundLocalError: 
                            pass 
                        notclicked = False 
                        displayinfo() 
                        break 

def errormsg(ln1: str, ln2: str): 
    rectwithtext(0, 0, 700, 30, ln1, None, activecol, True, 32) 
    rectwithtext(0, 30, 700, 500, ln2, None, activecol, True, 32) 
    errormsg = True 
    while errormsg: 
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT: 
                errormsg = False 
                global run 
                run = False 
            if event.type == pygame.MOUSEBUTTONDOWN: 
                errormsg = False 
                break 

try:
    with open(f"{projectname}.pickle", "rb") as read: 
        Main_Folder = pickle.load(read) 
except (FileNotFoundError, EOFError) as error: 
    # print("cannot, create") 
    errormsg("Welcome to Item Locator. ", "Please refrain from using the terminal/shell to close the program. Instead, please close the program on the pygame window to avoid losing changes. ") 
    print("Welcome to Item Locator. ") 
    print("Please refrain from using the terminal/shell to close the program. Instead, please close the program on the pygame window to avoid losing changes. ") 
    Main_Folder = Folder("Main Folder", "NIL") 


adjusty = 0 
viewing = Main_Folder 
displayinfo() 
run = True 
while run: 
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT: 
            run = False 
            with open(f"{projectname}.pickle", "wb") as write: 
                pickle.dump(Main_Folder, write) 
        if event.type == pygame.MOUSEBUTTONDOWN: 
            if event.button == 1: 
                for item in viewing.items: 
                    if item.rect.collidepoint(event.pos): 
                        if type(item).__name__ == "Folder": 
                            viewing = item 
                            adjusty = 0 
                            displayinfo() 
                        else: 
                            try: 
                                startfile(item.info) 
                            except FileNotFoundError: 
                                errormsg("Error: File Not Found. ", "Creating new file. Old contents would not be there. ") 
                                item.info = "infos\\{} Info.txt".format(convertstr(item.name)) 
                                with open (item.info, "w") as f: 
                                    f.write(f"{item.name}\'s information: Empty ") 
                if not viewing.name == "Main Folder": 
                    if backbutton.collidepoint(event.pos): 
                        viewing = viewing.location 
                        displayinfo() 
                else: 
                    backbutton = rectwithtext(500, 0, 100, 30, "Back", None, inactivecol, True) 
                    backcolour = True 
                    lasttime = pygame.time.get_ticks() 
                if searchbutton.collidepoint(event.pos): 
                    searchitem = inputbox(0, 0, 700, 30, None, "Item to search for") 
                    if find(searchitem, Main_Folder): 
                        viewing = location 
                        displayinfo() 
                    else: 
                        errormsg("Item not found. ", "Please check if spelling is correct. ") 
                        displayinfo() 
            elif event.button == 3: 
                clickitem = False 
                for item in viewing.items: 
                    if item.rect.collidepoint(event.pos): 
                        clickitem = True 
                        displayops(type(item).__name__, event, item) 
                if not clickitem: 
                    displayops("space", "", "") 
            elif event.button == 4: 
                adjusty = min(adjusty + 30, 0) 
                displayinfo() 
            elif event.button == 5: 
                adjusty -= 30 
                displayinfo() 
    if backcolour: 
        if pygame.time.get_ticks()-lasttime >= 200: 
            backbutton = rectwithtext(500, 0, 100, 30, "Back", None, activecol, True) 
            backcolour = False 
        # saving 
    with open(f"{projectname}.pickle", "wb") as write: 
        pickle.dump(Main_Folder, write) 
