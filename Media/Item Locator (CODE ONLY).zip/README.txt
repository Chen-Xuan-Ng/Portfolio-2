Please install "Python" and "Pygame" before running the code 

Installing "Python": 
https://www.python.org/downloads/ 

Installing "Pygame": 
	Windows: Open Command Prompt (press "Windows" keys and enter "cmd") type >>>"pip install pygame"
	MacOS: https://www.geeksforgeeks.org/install-pygame-in-macos/ --> Open "terminal" and enter "brew install python3" then enter "xcode-select --install" then enter "pip3 install pygame" (not tested) 
	Linux: https://artofproblemsolving.com/wiki/index.php/Getting_Started_With_Pygame#:~:text=Open%20a%20terminal%2C%20and%20type,prompt%20enter%20'import%20pygame (not tested) 

Run code: 
Open the folder the program is in and right click "Item Locator.py". Click open with --> Python 

Done! 

Note: You may have to run it twice. I had to do so